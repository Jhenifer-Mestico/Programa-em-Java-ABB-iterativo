// Classe ABB para demonstrar a inserção, busca, remoção, atravessamentos etc.
// em uma Árvore Binária de Busca (ABB).

// Ledón, 2016/2017; Amilton Souza Martha, 2015/2017.

package testa_abb;

public class Testa_ABB {  

    public static void main(String[] args) {
        
       System.out.println("\nVamos criar uma ABB com objetos da classe Integer:\n");
        ABB abb1 = new ABB();
        System.out.println( "Inserimos: " + abb1.inserir(12) );
        System.out.println( "Inserimos: " + abb1.inserir(6) );
        System.out.println( "Inserimos: " + abb1.inserir(4) );
        System.out.println( "Inserimos: " + abb1.inserir(15) );
        System.out.println( "Inserimos: " + abb1.inserir(13) );
        System.out.println( "Inserimos: " + abb1.inserir(25) );
        
        System.out.println("\nABB pré-ordem (iterativo):");
        abb1.preOrdemNaoRecursivo(abb1.getRaiz());
        System.out.println("\n\nABB pré-ordem (recursivo):");
        abb1.preOrdem(abb1.getRaiz());
        
    }
    
}